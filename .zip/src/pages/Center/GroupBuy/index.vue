<template>
  <div>
    <h1>GroupBuy</h1>
    <h1>GroupBuy</h1>
    <h1>GroupBuy</h1>
    <h1>GroupBuy</h1>
  </div>
</template>

<script>
export default {
  name:'GroupBuy',
}
</script>

<style  lang='less' scoped>

</style>